<footer class="main-footer">
	<div class="float-right d-none d-sm-block">
		<b>Version</b> 3.0.1-pre
	</div>
	<strong>Copyright Web Programming II</strong>
</footer>

<div id="sidebar-overlay"></div>
<!-- ./wrapper -->

