<?php

namespace App\Http\Controllers;

use App\Models\Produkmodel;
use Illuminate\Http\Request;

class Produk extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('produk/list');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    return view('produk/form');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        ////validasi data form
        $request->validate([
            'kode_produk' => 'required|unique:produk,kode_produk',
            'nama_produk' => 'required',
            'deskripsi' => 'required',
            'stok_produk' => 'required|min:1|numeric',
            'harga_jual' => 'required|min:1000|numeric'
                ]);
            $produk = new Produkmodel([
            'kode_produk' => $request->get('kode_produk'),
            'nama_produk' => $request->get('nama_produk'),
            'deskripsi' => $request->get('deskripsi'),
            'stok' => $request->get('stok_produk'),
            'harga' => $request->get('harga_jual'),
            'foto_produk' => '',
                ]);
            $saved = $produk->save();
            if(!$saved){
            $data_json = [
            'pesan' => 'Gagal Menambah Data',
            'produk' => $produk,
                ];
            } else {
            $data_json = [
            'pesan' => 'Sukses',
            'produk' => $produk,
                ];
            }
            return json_encode($data_json);
        
            return view('produk/form');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Produkmodel  $produkmodel
     * @return \Illuminate\Http\Response
     */
    public function show(Produkmodel $produkmodel)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Produkmodel  $produkmodel
     * @return \Illuminate\Http\Response
     */
    public function edit(Produkmodel $produkmodel)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Produkmodel  $produkmodel
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Produkmodel $produkmodel)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Produkmodel  $produkmodel
     * @return \Illuminate\Http\Response
     */
    public function destroy(Produkmodel $produkmodel)
    {
        //
    }

    public function getListProduk(Produkmodel $produkmodel)
    {
        $data = $produkmodel::all();

        return json_encode($data);
    }

    public function getByKode(Produkmodel $produkmodel, $kode)
    {
        $data = $produkmodel::where('kode_produk', 'LIKE', "%{$kode}%")->get();

        return json_encode($data);
    }
}
