<footer class="main-footer">
	<div class="float-right d-none d-sm-block">
		<b>Version</b> 3.0.1-pre
	</div>
	<strong>Copyright Web Programming II</strong>
</footer>

<div id="sidebar-overlay"></div>
<!-- ./wrapper -->

<?php /**PATH E:\22.02.0836\share-cart_laravel_no_public_vendor\resources\views/template/call_footer.blade.php ENDPATH**/ ?>