<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>
    <?php echo $__env->yieldContent('judul'); ?>
  </title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(url('adminLTE/plugins/fontawesome-free/css/all.min.css')); ?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo e(url('adminLTE/dist/css/adminlte.min.css')); ?>">
</head>
<?php /**PATH E:\22.02.0836\share-cart_laravel_no_public_vendor\resources\views/template/call_head.blade.php ENDPATH**/ ?>