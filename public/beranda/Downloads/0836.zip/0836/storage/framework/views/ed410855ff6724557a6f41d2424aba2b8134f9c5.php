<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>
    <?php echo $__env->yieldContent('judul'); ?>
  </title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(url('adminLTE/plugins/fontawesome-free/css/all.min.css')); ?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo e(url('adminLTE/dist/css/adminlte.min.css')); ?>">
</head>
<?php /**PATH E:\demo materi\cart_online\cart_laravel\resources\views/template/call_head.blade.php ENDPATH**/ ?>