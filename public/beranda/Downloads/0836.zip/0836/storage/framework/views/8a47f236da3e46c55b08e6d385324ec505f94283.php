<?php $__env->startSection('judul'); ?>
    List Produk
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>
<form>
    <div class="row">
        <div class="col">
            <label>Masukkan Kode</label>
            <input class="form-control" type="text" name="cari" id="cari">
        </div>
        <div class="col">
            <input type="submit" value="Cari ID" class="btn btn-primary" style="margin-top:33px">
        </div>
    </div>
</form>

<table border="1" id="data-list" class="table">
    <tr>
        <th>No.</th>
        <th>Kode</th>
        <th>Nama</th>
        <th>Stok</th>
        <th>Harga</th>
        <th>Deskripsi</th>
        <th>Gambar</th>
        <th>OPSI</th>
    </tr>
</table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script_custom'); ?>
<script>
    $(document).ready(function(){

        function ambil_data(kode = '') {
            if (kode == '') {
                var link = '<?php echo e(url("api/produk/all")); ?>';
            } else {
                var link = '<?php echo e(url("api/produk/kode/")); ?>' + '/' + kode;
            }


            $.ajax(link, {
                type: 'GET',
                success : function (data, status, xhr) {
                    resetTable();
                    var objData = JSON.parse(data);
                    var dataTable = '';
                    $.each( objData, function( key, value ) {
                        dataTable += '<tr>';
                        dataTable += '<td>'+(key+1)+'</td>';
                        dataTable += '<td>'+value.kode_produk+'</td>';
                        dataTable += '<td>'+value.nama_produk+'</td>';
                        dataTable += '<td>'+value.stok+'</td>';
                        dataTable += '<td>Rp '+value.harga+'</td>';
                        dataTable += '<td>'+value.deskripsi+'</td>';
                        dataTable += '<td><img src="'+value.foto_produk+'"></td>';
                        dataTable += '<td><a href="#" class="btn btn-info">Ubah</a> <a href="#"  class="btn btn-danger">Hapus</a></td>';
                        dataTable += '</tr>';
                    });

                    $( "#data-list" ).append( dataTable );
                },
                error : function (jqXHR, textStatus, errorMsg) {
                    alert('Error Pengambilan Data : ' + errorMsg);
                }
            })
        }

        ambil_data();

        $("form").on('submit', function(e){
            e.preventDefault();
            var kode = $("input[name=cari]").val();
            ambil_data(kode);
        })

        function resetTable() {
        	$( "#data-list" ).html( "<tr> <th>No.</th> <th>Kode</th> <th>Nama</th> <th>Stok</th> <th>Harga</th> <th>Deskripsi</th> <th>Gambar</th> <th>OPSI</th> </tr>" );
        }

    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\demo materi\cart_online\cart_laravel\resources\views/produk/list.blade.php ENDPATH**/ ?>