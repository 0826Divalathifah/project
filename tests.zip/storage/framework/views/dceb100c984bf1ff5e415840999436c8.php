<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Desa Mandiri Budaya'); ?></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="manifest" href="site.webmanifest">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('themewagon/img/favicon.ico')); ?>">
    <?php echo $__env->make('beranda.partials.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Panggil file CSS -->

</head>
<body>
    <?php echo $__env->make('beranda.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Header -->

    <main>
        <?php echo $__env->yieldContent('content'); ?> <!-- Konten halaman -->
    </main>

    <?php echo $__env->make('beranda.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Footer -->

    <!-- Scroll Up -->
    <div id="back-top">
        <a title="Go to Top" href="#"> <i class="fas fa-level-up-alt"></i></a>
    </div>

    <?php echo $__env->make('beranda.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Panggil file JS -->
</body>
</html>
<?php /**PATH C:\xampp\htdocs\project\resources\views/beranda/layouts/app.blade.php ENDPATH**/ ?>