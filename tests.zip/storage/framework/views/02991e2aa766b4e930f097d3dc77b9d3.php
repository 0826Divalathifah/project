<!--  CSS here -->
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/slicknav.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/progressbar_barfiller.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/gijgo.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/animated-headline.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/magnific-popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/fontawesome-all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/nice-select.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/calendar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/whatsapp.css')); ?>"><?php /**PATH C:\xampp\htdocs\project\resources\views/beranda/partials/styles.blade.php ENDPATH**/ ?>