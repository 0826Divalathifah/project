<script src="<?php echo e(asset('themewagon/js/calendar.js')); ?>"></script>

<!-- Nice-select, sticky,Progress -->
<script src="<?php echo e(asset('themewagon/js/jquery.nice-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.sticky.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.barfiller.js')); ?>"></script>

<!-- counter , waypoint,Hover Direction -->
<script src="<?php echo e(asset('themewagon/js/jquery.counterup.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.countdown.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/hover-direction-snake.min.js')); ?>"></script>

<!-- contact js -->
<script src="<?php echo e(asset('themewagon/js/contact.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.form.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/mail-script.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.ajaxchimp.min.js')); ?>"></script>

<!-- Jquery Plugins, main Jquery -->	
<script src="<?php echo e(asset('themewagon/js/plugins.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/whatsapp.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/detail.js')); ?>"></script>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script><?php /**PATH C:\xampp\htdocs\project\resources\views/beranda/partials/scripts.blade.php ENDPATH**/ ?>