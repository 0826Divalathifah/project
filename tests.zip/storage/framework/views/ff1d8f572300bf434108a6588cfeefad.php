<!doctype html>
<html class="no-js" lang="zxx">
<head>
<meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Kontak</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="manifest" href="site.webmanifest">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('themewagon/img/favicon.ico')); ?>">

    <meta name="description" content="" />
    <meta name="keywords" content="bootstrap, bootstrap4" />

    <!-- Bootstrap CSS -->
    <link href="<?php echo e(asset('furni/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('furni/css/tiny-slider.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('furni/css/style.css')); ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">


        <!-- CSS themewagon -->
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/slicknav.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/progressbar_barfiller.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/gijgo.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/animated-headline.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/magnific-popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/fontawesome-all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/nice-select.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/style.css')); ?>">

    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet">

</head>
<body class="full-wrapper">
    <!-- Preloader Start -->
    <div id="preloader-active">
        <div class="preloader d-flex align-items-center justify-content-center">
            <div class="preloader-inner position-relative">
                <div class="preloader-circle"></div>
                <div class="preloader-img pere-text">
                <img src="<?php echo e(asset('themewagon/img/logo/logo Kabupaten Sleman.png')); ?>" alt="">
                </div>
            </div>
        </div>
    </div>
    <!-- Preloader End -->
<header>
    <!-- Header Start -->
    <div class="header-area">
        <div class="main-header header-sticky">
            <div class="container-fluid">
                <div class="menu-wrapper d-flex align-items-center justify-content-between">
                    <div class="header-left d-flex align-items-center">
                         <!-- Logo -->
                         <div class="logo">
                            <a href="<?php echo e(url('/')); ?>">
                                <img src="<?php echo e(asset('themewagon/img/logo/logo_header.png')); ?>" alt="Logo Kabupaten Sleman" style="width: 97 px; height: 70px;">
                                </a></div>
                        <!-- Main-menu -->
                        <div class="main-menu d-none d-lg-block">
                            <nav>
                                <ul id="navigation">
                                    <li><a href="<?php echo e(url('/')); ?>">Beranda</a></li>
                                    <li><a href="#">Desa Mandiri Budaya</a>
                                        <ul class="submenu">
                                            <li><a href="<?php echo e(url('/desabudaya')); ?>">Desa Budaya </a></li>
                                            <li><a href="<?php echo e(url('/desaprima')); ?>">Desa Prima</a></li>
                                            <li><a href="<?php echo e(url('/desapreneur')); ?>">Desa Preneur</a></li>
                                            <li><a href="<?php echo e(url('/desawisata')); ?>">Desa Wisata</a></li>
                                        </ul>
                                    <li>   
                                    <li><a href="<?php echo e(url('/about')); ?>">Tentang Kami</a></li>
                                    <li><a href="<?php echo e(url('/contact')); ?>">Kontak</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <div class="header-right1 d-flex align-items-center">
                        <!-- Social -->
                        <div class="header-social d-none d-md-block">
                        <a href="https://sinduharjosid.slemankab.go.id/first"><i class="fas fa-globe"></i></a>
                                <a href="https://www.instagram.com/"><i class="fab fa-instagram"></i></a>
                                <a href="https://www.youtube.com/"><i class="fab fa-youtube"></i></a>
                        </div>
                        <!-- Search Box 
                        <div class="search d-none d-md-block">
                            <ul class="d-flex align-items-center">
                                <li class="mr-15">
                                    <div class="nav-search search-switch">
                                        <i class="ti-search"></i>
                                    </div>
                                </li>
                            </ul>
                        </div>-->
                    </div>
                    <!-- Mobile Menu -->
                    <div class="col-12">
                        <div class="mobile_menu d-block d-lg-none"></div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Header End -->
    </header>
    <main>
        <!-- header end -->
        <!-- listing Area Start -->
            <div class="category-area">
            <div class="container">
            <div class="row">
            
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <style>
        /* Styling for the banner */
        .banner-container {
            position: relative;
            text-align: center;
            color: white;
            height: 600px;
            background: url('<?php echo e(asset('themewagon/img/desabudaya/banner.jpg')); ?>') no-repeat center center/cover;
            margin-bottom: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        }

        .banner-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            pointer-events: none; /* Membuat overlay tidak memblokir interaksi */
        }

        .banner-content {
            position: relative;
            z-index: 2; /* Pastikan ini berada di atas overlay */
            text-align: center;
        }

        .banner-text {
            font-size: 48px;
            font-weight: bold;
            z-index: 3; 
            letter-spacing: 3px;
            text-transform: uppercase;
            text-shadow: 3px 3px 5px rgba(0, 0, 0, 0.7);
            margin-top: 100px;
        }

        .breadcrumb {
            margin-top: 20px;
            font-size: 18px;
            color: #ffffff;
        }

        .breadcrumb-item a {
            color: #ffffff;
            text-decoration: none;
            z-index: 3; /* Pastikan link memiliki z-index yang lebih tinggi */
            position: relative; /* Penting untuk memastikan z-index bekerja */
        }

        .breadcrumb-item a:hover {
            color: #ffffff;
            text-decoration: underline;
        }
        
    </style>

        <div class="banner-container">
        <!-- Mobile Device Show Menu-->
        <div class="header-right2 d-flex align-items-center">
                    <!-- Social -->
                    <div class="header-social  d-block d-md-none">
                    <a href="https://sinduharjosid.slemankab.go.id/first"><i class="fas fa-globe"></i></a>
                    <a href="https://www.instagram.com/kalurahan_sinduharjo?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="><i class="fab fa-instagram"></i></a>
                    <a href="https://www.youtube.com/"><i class="fab fa-youtube"></i></a>
                    <!-- Ikon Login dan Sign Up -->
                    </div>
        </div>
            <div class="banner-overlay"></div>
            <div class="banner-text">Kontak</div>

            <?php if(isset($gambar_banner) && file_exists(public_path('storage/' . $gambar_banner))): ?>
                            <img src="<?php echo e(asset('storage/' . $gambar_banner)); ?>" alt="Banner" class="banner-image">
                        <?php else: ?>
                            <img src="<?php echo e(asset('themewagon/img/desabudaya/banner.jpg')); ?>" alt="Banner" class="banner-image">
                        <?php endif; ?>

            <!-- Breadcrumb Start -->
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Beranda</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(url('#')); ?>">Kontak</a></li>
                </ol>
            </nav>
            <!-- Breadcrumb End -->
        </div>
        
        <!--?  Contact Area start  -->
        <section class="contact-section">
        <div class="container" style="max-width: 100%; height: auto;">
    <hr>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3953.6740283935355!2d110.40316631744383!3d-7.718081099999983!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e7a59c8182df777%3A0x4b7a5afe863a3e07!2sKantor%20Kalurahan%20Sinduharjo!5e0!3m2!1sen!2sid!4v1724989066318!5m2!1sen!2sid" 
        width="100%" height="600" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    <div class="d-none d-sm-block mb-5 pb-4">
        <script>
            function initMap() {
                var uluru = { lat: -25.363, lng: 131.044 };
                var grayStyles = [{
                    featureType: "all",
                    stylers: [{ saturation: -90 }, { lightness: 50 }]
                }, {
                    elementType: 'labels.text.fill',
                    stylers: [{ color: '#ccdee9' }]
                }];
                var map = new google.maps.Map(document.getElementById('map'), {
                    center: { lat: -31.197, lng: 150.744 },
                    zoom: 9,
                    styles: grayStyles,
                    scrollwheel: false
                });
            }
        </script>
    </div>
</div>
    
                    
                </div>
                <div class="row" style="margin-top: 20px;">
                <div class="col-24">
                    <h3 class="contact-title">
                        Kesan dan Pesan
                    </h3>
                </div>
            </div>

            <div class="col-lg-12">
            <form class="form-contact contact_form" action="/simpanFeedback" method="POST" id="contactForm" novalidate="novalidate">
            <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-12">
                <div class="form-group">
                    <textarea class="form-control w-100" name="message" id="message" cols="30" rows="9" placeholder="Kirim Pesan" required></textarea>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                <input class="form-control valid" name="name" id="name" type="text" placeholder="Masukkan Nama Anda">
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <input class="form-control valid" name="email" id="email" type="email" placeholder="Email">
                </div>
            </div>
            <div class="form-group mt-3">
                <button type="button" id="submitFeedback" class="button button-contactForm boxed-btn">Kirim Pesan</button>
            </div>
        </div>
    </form>
</div>


                    <div class="col-lg-3 offset-lg-1">
                        <div class="media contact-info">
                            <span class="contact-info__icon"><i class="ti-home"></i></span>
                            <div class="media-body">
                                <h3>Kalurahan Sinduharjo</h3>
                                <p>Jalan Kaliurang Km 10.5, Gentan, Ngaglik, Sleman, Yogyakarta</p>
                            </div>
                        </div>
                        <div class="media contact-info">
                            <span class="contact-info__icon"><i class="ti-tablet"></i></span>
                            <div class="media-body">
                                <h3>(0274) 882723</h3>
                                <p>Senin-Jumat 08.00 WIB - 15.00 WIB</p>
                            </div>
                        </div>
                        <div class="media contact-info">
                            <span class="contact-info__icon"><i class="ti-email"></i></span>
                            <div class="media-body">
                                <h3>kalurahansinduharjo@gmail.com</h3>
                                <p>Kirimkan pertanyaan Anda kepada kami kapan saja</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Contact Area End -->
    </main>
    <footer>
    <!-- Footer Start -->
    <div class="footer-area footer-padding">
        <div class="container-fluid">
            <div class="row d-flex justify-content-around">
                <!-- Logo and Social Media -->
                <div class="col-xl-3 col-lg-3 col-md-8 col-sm-8 d-flex justify-content-center">
                    <div class="single-footer-caption mb-50">
                        <!-- Logo -->
                        <div class="footer-logo mb-35" style="text-align: right;">
                            <a href="<?php echo e(url('/')); ?>">
                                <img src="<?php echo e(asset('themewagon/img/logo/logo_footer.png')); ?>" alt="Logo Kelurahan Sinduharjo" style="width: 400px; height: 120px;">
                            </a>
                        </div>
                        <!-- Social Media Icons -->
                        <div class="footer-social">
                            <a href="https://sinduharjosid.slemankab.go.id/first" class="mr-2"><i class="fas fa-globe"></i></a>
                            <a href="https://www.instagram.com/kalurahan_sinduharjo" class="mr-2"><i class="fab fa-instagram"></i></a>
                            <a href="https://www.youtube.com/"><i class="fab fa-youtube"></i></a>
                        </div>
                    </div>
                </div>

                <!-- Quick Links -->
                <div class="col-xl-2 col-lg-2 col-md-4 col-sm-4">
                    <div class="single-footer-caption mb-50">
                        <div class="footer-tittle">
                            <h4>Link</h4>
                            <ul>
                                <li><a href="<?php echo e(url('/desabudaya')); ?>">Desa Budaya</a></li>
                                <li><a href="<?php echo e(url('/desaprima')); ?>">Desa Prima</a></li>
                                <li><a href="<?php echo e(url('/desapreneur')); ?>">Desa Preneur</a></li>
                                <li><a href="<?php echo e(url('/desawisata')); ?>">Desa Wisata</a></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- Contact Info -->
                <div class="col-xl-2 col-lg-3 col-md-4 col-sm-4">
                    <div class="single-footer-caption mb-35" style= "text-align: left;">
                        <div class="footer-tittle">
                            <h4>Kontak</h4>
                            <ul>
                                <li><a href="#">(0274) 882723</a></li>
                                <li><a href="#">kalurahansinduharjo@gmail.com</a></li>
                                <li><a href="#">Jalan Kaliurang Km 10.5, Gentan, Ngaglik, Sleman, Yogyakarta</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer-Bottom Area -->
    <div class="footer-bottom-area">
        <div class="container">
            <div class="footer-border">
                <div class="row d-flex align-items-center">
                    <div class="col-xl-12">
                        <div class="footer-copy-right text-center">
                            <p>
                                Copyright &copy; <script>document.write(new Date().getFullYear());</script>
                                All rights reserved | Kalurahan Sinduharjo
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->
</footer>
<!--? Search model Begin
<div class="search-model-box">
    <div class="h-100 d-flex align-items-center justify-content-center">
        <div class="search-close-btn">+</div>
        <form class="search-model-form">
            <input type="text" id="search-input" placeholder="Searching key.....">
        </form>
    </div>
</div> -->


<!-- Scroll Up -->
<div id="back-top" >
    <a title="Go to Top" href="#"> <i class="fas fa-level-up-alt"></i></a>
</div>



<!-- JS here -->
<!-- Jquery, Popper, Bootstrap -->
<script src="<?php echo e(asset('themewagon/js/vendor/modernizr-3.5.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/vendor/jquery-1.12.4.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/bootstrap.min.js')); ?>"></script>


<!-- Slick-slider , Owl-Carousel ,slick-nav -->
<script src="<?php echo e(asset('themewagon/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.slicknav.min.js')); ?>"></script>

<!-- One Page, Animated-HeadLin, Date Picker -->
<script src="<?php echo e(asset('themewagonjs/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/animated.headline.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.magnific-popup.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/gijgo.min.js')); ?>"></script>


<!-- Nice-select, sticky,Progress -->
<script src="<?php echo e(asset('themewagon/js/jquery.nice-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.sticky.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.barfiller.js')); ?>"></script>

<!-- counter , waypoint,Hover Direction -->
<script src="<?php echo e(asset('themewagon/js/jquery.counterup.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.countdown.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/hover-direction-snake.min.js')); ?>"></script>

<!-- contact js -->
 <script src="<?php echo e(asset('themewagon/js/contact.js')); ?>"></script> 
 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script> -->
<!-- <script src="<?php echo e(asset('themewagon/js/jquery.form.js')); ?>"></script> -->
<!-- <script src="<?php echo e(asset('themewagon/js/jquery.validate.min.js')); ?>"></script> -->
<!-- <script src="<?php echo e(asset('themewagon/js/mail-script.js')); ?>"></script> -->
<!-- <script src="<?php echo e(asset('themewagon/js/jquery.ajaxchimp.min.js')); ?>"></script> -->

<!-- Jquery Plugins, main Jquery -->	
<script src="<?php echo e(asset('themewagon/js/plugins.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/main.js')); ?>"></script>

</body>
</html><?php /**PATH C:\xampp\htdocs\project\resources\views/beranda/contact.blade.php ENDPATH**/ ?>