<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Application</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>"> <!-- Sesuaikan dengan CSS Anda -->
</head>
<body>
    <header>
        <h1>My Application</h1>
        <!-- Menu atau elemen header lainnya -->
    </header>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer>
        <p>&copy; 2024 My Application</p>
    </footer>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script> <!-- Sesuaikan dengan JS Anda -->
</body>
</html>
<?php /**PATH C:\xampp\htdocs\project\resources\views/layouts/app.blade.php ENDPATH**/ ?>