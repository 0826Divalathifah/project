<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Desa Budaya</title>

    <!-- plugins:css -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendors/feather/feather.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendors/ti-icons/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendors/css/vendor.bundle.base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendors/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendors/mdi/css/materialdesignicons.min.css')); ?>">
    <!-- endinject -->

    <!-- Plugin css for this page -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendors/datatables.net-bs5/dataTables.bootstrap5.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendors/ti-icons/css/themify-icons.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin/assets/js/select.dataTables.min.css')); ?>">
    
    <!-- End plugin css for this page -->

    <!-- inject:css -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/style.css')); ?>">
    <!-- endinject -->

    <link rel="shortcut icon" href="<?php echo e(asset('admin/assets/images/favicon.png')); ?>">
  </head>

  <div class="container-scroller">
  <!-- partial:../../partials/_navbar.html -->
  <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
          <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-start">
          <a class="navbar-brand brand-logo me-5" href="<?php echo e(url ('/adminbudaya')); ?>" >
              <img src="<?php echo e(asset('themewagon/img/logo/logo_header.png')); ?>" alt="Logo Kabupaten Sleman" style="width: 110 px; height: 52px;">
            </a>
            <a class="navbar-brand brand-logo-mini" href="<?php echo e(url('/adminbudaya')); ?>">
              <img src="<?php echo e(asset('themewagon/img/logo/logo kabupaten sleman.png')); ?>"  alt="Logo Kabupaten Sleman" style="width: 100 px; height: 40px;">
            </a>
          </div>
          <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
            <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
              <span class="icon-menu"></span>
            </button>

    <ul class="navbar-nav navbar-nav-right">
    <div class="header-right1 d-flex align-items-center justify-content-center">
    <!-- Social -->
    <div class="header-social d-flex align-items-center">
        <!-- Icon Power -->
        <a class="nav-link d-flex align-items-center mx-3" href="#">
            <i class="ti-power-off text-primary" style="font-size: 24px; margin-right: 10px;"></i>
            <span style="font-size: 16px;">Logout</span>
        </a>
    </div>
</div>    
    <li class="nav-item nav-settings d-none d-lg-flex">
        <a class="nav-link" href="#">
            <i class="mdi mdi-arrow-up-bold-circle-outline"></i>
        </a>
    </li>
</ul>

<button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
    <span class="icon-menu"></span>
</button>

  </div>
</nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(asset('/adminbudaya')); ?>">
                <i class="icon-grid menu-icon"></i>
                <span class="menu-title">Dashboard</span>
              </a>
          </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('/kelolabudaya')); ?>">
                <i class="mdi mdi-shape-plus menu-icon"></i>
                <span class="menu-title">Kelola Budaya</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('/kelolaagenda')); ?>">
                <i class="mdi mdi-calendar-plus menu-icon"></i>
                <span class="menu-title">Kelola Agenda</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('/kelolahomepagebudaya')); ?>">
                <i class="mdi mdi-home menu-icon"></i>
                <span class="menu-title">Kelola Home Page</span>
              </a>
            </li>
        </nav>

        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="row">
              <div class="col-md-12 grid-margin">
                <div class="row">
                  <div class="col-12 col-xl-8 mb-4 mb-xl-0">
                    <h3 class="font-weight-bold">Selamat Datang, </h3>
                    <p id="currentDateTime"></p>
                  </div>
                  
                </div>
              </div>
            </div>
    <div class="col-md-12 grid-margin transparent">
    <div class="row">
        <!-- Card 1 -->
        <div class="col-md-4 mb-4 stretch-card transparent">
            <div class="card card-tale">
                <div class="card-body">
                    <p class="mb-4">Total Budaya</p>
                    <p class="fs-30 mb-2"><?php echo e($totalBudaya); ?></p>
                    <p>Budaya</p>
                </div>
            </div>
        </div>

        <!-- Card 2 -->
        <div class="col-md-4 mb-4 stretch-card transparent">
            <div class="card card-dark-blue">
                <div class="card-body">
                    <p class="mb-4">Total Agenda</p>
                    <p class="fs-30 mb-2"><?php echo e($totalAgenda); ?></p>
                    <p>Agenda</p>
                </div>
            </div>
        </div>

        <!-- Card 3 -->
        <div class="col-md-4 mb-4 stretch-card transparent">
            <div class="card card-light-blue">
                <div class="card-body">
                <p class="mb-4">Total Kunjungan Desa Budaya</p>
                <p class="fs-30 mb-2"><?php echo e($totalVisitsDesaBudaya); ?></p>
                <p>kali</p>
                </div>
            </div>
        </div>

        <!-- Card 4 
        <div class="col-md-3 mb-4 stretch-card transparent">
            <div class="card card-light-danger">
                <div class="card-body">
                    <p class="mb-4">Total Transaksi</p>
                    <p class="fs-30 mb-2">567</p>
                    <p>0.22% (30 days)</p>
                </div>
            </div>
        </div>-->
  </div>
</div>
<div class="row">
  <div class="col-md-6 grid-margin stretch-card">
      <div class="card">
          <div class="card-body">
              <div class="d-flex justify-content-between align-items-center">
                  <p class="card-title">Jumlah Kunjungan Desa Budaya</p>
                  <select id="filter" class="form-select w-25" data-desa="Desa Budaya">
                      <option value="daily" <?php echo e($filter == 'daily' ? 'selected' : ''); ?>>Harian</option>
                      <option value="weekly" <?php echo e($filter == 'weekly' ? 'selected' : ''); ?>>Mingguan</option>
                      <option value="monthly" <?php echo e($filter == 'monthly' ? 'selected' : ''); ?>>Bulanan</option>
                      <option value="yearly" <?php echo e($filter == 'yearly' ? 'selected' : ''); ?>>Tahunan</option>
                  </select>
              </div>
              <!-- Elemen untuk menyimpan data -->
              <canvas id="desaBudayaChart" height="150" 
                  data-labels="<?php echo e(implode(',', $labels)); ?>" 
                  data-data="<?php echo e(implode(',', $data)); ?>">
              </canvas>
          </div>
      </div>
  </div>

  <div class="col-md-6 grid-margin stretch-card">
      <div class="card">
          <div class="card-body">
              <div class="d-flex justify-content-between">
                  <p class="card-title">Jumlah Agenda</p>
                  <a href="<?php echo e(url('/kelolaagenda')); ?>" class="text-info">View all</a>
              </div>

              <!-- Dropdown Filter -->
              <form method="GET" action="<?php echo e(url('/adminbudaya')); ?>" id="filterForm">
                  <div class="row mb-3">
                      <div class="col-md-6">
                          <select name="year" class="form-control" onchange="document.getElementById('filterForm').submit();">
                              <?php for($i = 2024; $i <= date('Y'); $i++): ?>
                                  <option value="<?php echo e($i); ?>" <?php echo e(request('year') == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                              <?php endfor; ?>
                          </select>
                      </div>
                      <div class="col-md-6">
                          <select name="month" class="form-control" onchange="document.getElementById('filterForm').submit();">
                              <option value="">Semua Bulan</option>
                              <?php $__currentLoopData = range(1, 12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($m); ?>" <?php echo e(request('month') == $m ? 'selected' : ''); ?>>
                                      <?php echo e(Carbon\Carbon::create()->month($m)->format('F')); ?>

                                  </option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                      </div>
                  </div>
              </form>

              <div id="sales-chart-legend" class="chartjs-legend mt-4 mb-2"></div>
              <canvas id="sales-chart" 
                  data-agenda-labels="<?php echo e(json_encode($agendaLabels)); ?>" 
                  data-agenda-totals="<?php echo e(json_encode($agendaTotals)); ?>">
              </canvas>
          </div>
      </div>
  </div>

      
<div class="row">
  <div class="col-12 grid-margin stretch-card">
      <div class="card">
          <div class="card-body">
            <p class="card-title mb-10">Daftar Agenda Yang Akan Datang</p>
            <div class="table-responsive">
                <table class="table table-striped table-borderless">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Acara</th>
                            <th>Tanggal Acara</th>
                        </tr>
                    </thead>
                    <tbody>
                      <?php $__empty_1 = true; $__currentLoopData = $agendaComing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $agenda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                          <tr>
                              <td><?php echo e($index + 1); ?></td>
                              <td><?php echo e($agenda->nama_acara); ?></td>
                              <td><?php echo e(\Carbon\Carbon::parse($agenda->tanggal_acara)->format('d M Y')); ?></td>
                          </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          <tr>
                              <td colspan="3" class="text-center">Tidak ada agenda yang akan datang.</td>
                          </tr>
                      <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>
          
<div class= "row">
  <div class="col-md-12 grid-margin stretch-card">
      <div class="card">
          <div class="card-body">
          <div class="d-flex justify-content-between">
              <p class="card-title mb-10">Daftar Budaya</p>
              <a href="<?php echo e(url('/kelolabudaya')); ?>" class="text-info">View all</a>
          </div>
                <div class="table-responsive">
                  <table id="example" class="display expandable-table" style="width:100%" >
                      <thead>
                          <tr>
                              <th>No</th>
                              <th>Nama Budaya</th>
                          </tr>
                      </thead>
                      <tbody>
                          <?php $__empty_1 = true; $__currentLoopData = $budaya; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                              <tr>
                                  <td><?php echo e($index + 1); ?></td>
                                  <td><?php echo e($item->nama_budaya); ?></td>
                              </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                              <tr>
                                  <td colspan="2" class="text-center">Tidak ada budaya yang tersedia.</td>
                              </tr>
                          <?php endif; ?>
                      </tbody>
                  </table>
              </div>
          </div>
      </div>
  </div>

<!-- main-panel ends -->
</div>
<!-- page-body-wrapper ends -->
</div>
<!-- container-scroller -->
    
<!-- plugins:js -->
<script src="<?php echo e(asset('admin/assets/vendors/js/vendor.bundle.base.js')); ?>"></script>
<!-- endinject -->
 <!-- Plugin js for this page -->
<script src="<?php echo e(asset('admin/assets/vendors/chart.js/chart.umd.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/vendors/datatables.net/jquery.dataTables.js')); ?>"></script>
<script src="assets/vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
<script src="<?php echo e(asset('admin/assets/vendors/datatables.net-bs5/dataTables.bootstrap5.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/dataTables.select..min.js')); ?>"></script>

<!-- Custom js for this page-->
<script src="<?php echo e(asset('admin/assets/js/off-canvas.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/template.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/settings.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/todolist.js')); ?>"></script>

<!-- Custom js for this page-->
<script src="<?php echo e(asset('admin/assets/js/jquery.cookie.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('admin/assets/js/dashboard.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/datetime.js')); ?>"></script>



<!-- End custom js for this page-->
</body>
</html>
<?php /**PATH C:\xampp\htdocs\project\resources\views/admin/adminbudaya/adminbudaya.blade.php ENDPATH**/ ?>