<!doctype html>

<html class="no-js" lang="zxx">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Detail Budaya</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="manifest" href="site.webmanifest">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('themewagon/img/favicon.ico')); ?>">

    <!--  CSS here -->
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/slicknav.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/progressbar_barfiller.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/gijgo.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/animated-headline.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/magnific-popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/fontawesome-all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/nice-select.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/calendar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/whatsapp.css')); ?>">

</head>

<body class="full-wrapper">
    <!-- Preloader Start -->
    <div id="preloader-active">
        <div class="preloader d-flex align-items-center justify-content-center">
            <div class="preloader-inner position-relative">
                <div class="preloader-circle"></div>
                    <div class="preloader-img pere-text">
                        <img src="<?php echo e(asset('themewagon/img/logo/logo Kabupaten Sleman.png')); ?>" alt="">
                    </div>
                </div>
            </div>
        </div>
    <!-- Preloader end -->

    <header>
    <!-- Header Start -->
    <div class="header-area">
        <div class="main-header header-sticky">
            <div class="container-fluid">
                <div class="menu-wrapper d-flex align-items-center justify-content-between">
                    <div class="header-left d-flex align-items-center">
                        <!-- Logo -->
                        <div class="logo">
                            <a href="<?php echo e(url('/')); ?>">
                            <img src="<?php echo e(asset('themewagon/img/logo/logo_header.png')); ?>" alt="Logo Kabupaten Sleman" style="width: 97 px; height: 70px;">
                            </a>
                        </div>
                        <!-- Main-menu -->
                        <div class="main-menu d-none d-lg-block">
                            <nav>
                                <ul id="navigation">
                                    <li><a href="<?php echo e(url('/')); ?>">Beranda</a></li>
                                    <li>
                                        <a href="#">Desa Mandiri Budaya</a>
                                        <ul class="submenu">
                                            <li><a href="<?php echo e(url('/desabudaya')); ?>">Desa Budaya</a></li>
                                            <li><a href="<?php echo e(url('/desaprima')); ?>">Desa Prima</a></li>
                                            <li><a href="<?php echo e(url('/desapreneur')); ?>">Desa Preneur</a></li>
                                            <li><a href="<?php echo e(url('/desawisata')); ?>">Desa Wisata</a></li>
                                        </ul>
                                    </li>  
                                    <li><a href="<?php echo e(url('/about')); ?>">Tentang Kami</a></li>
                                    <li><a href="<?php echo e(url('/contact')); ?>">Kontak</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <div class="header-right1 d-flex align-items-center">
                        <!-- Social -->
                        <div class="header-social d-none d-md-block">
                            <a href="https://sinduharjosid.slemankab.go.id/first"><i class="fas fa-globe"></i></a>
                            <a href="https://www.instagram.com/kalurahan_sinduharjo?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="><i class="fab fa-instagram"></i></a>
                            <a href="https://www.youtube.com/"><i class="fab fa-youtube"></i></a>
                        </div>
                        <!-- Search Box -->
                        <div class="search d-none d-md-block">
                            <ul class="d-flex align-items-center">
                                <li class="mr-15">
                                    <div class="nav-search search-switch">
                                        <i class="ti-search"></i>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- Mobile Menu -->
                    <div class="col-12">
                        <div class="mobile_menu d-block d-lg-none"></div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Header End -->
</header>


<main>
    <!-- listing Area Start -->
        <div class="container">
        <div class="category-area">
        <div class="row">

            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            
            <div class="banner-container">
                <!-- Mobile Device Show Menu-->
                <div class="header-right2 d-flex align-items-center">
                    <!-- Social -->
                    <div class="header-social  d-block d-md-none">
                    <a href="https://sinduharjosid.slemankab.go.id/first"><i class="fas fa-globe"></i></a>
                    <a href="https://www.instagram.com/kalurahan_sinduharjo?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="><i class="fab fa-instagram"></i></a>
                    <a href="https://www.youtube.com/"><i class="fab fa-youtube"></i></a>
                    <!-- Ikon Login dan Sign Up -->
                    </div>
                </div>
                <?php if(isset($homepageData->gambar_banner)): ?>
                    <img src="<?php echo e(asset('storage/' . $homepageData->gambar_banner)); ?>" alt="Banner" class="banner-image">
                <?php else: ?>
                <!-- Gambar default jika gambar_banner tidak tersedia -->
                    <img src="<?php echo e(asset('themewagon/img/desabudaya/banner.jpg')); ?>" alt="Banner" class="banner-image">
                    <?php endif; ?>
                <div class="banner-overlay"></div> <!-- Overlay -->
                <div class="banner-text">Detail Budaya</div> <!-- Teks di atas gambar -->
                    
                <!-- breadcrumb Start-->
                    <div class="breadcrumb">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center">
                                <li class="breadcrumb-item"><a href="<?php echo e(url('/desabudaya')); ?>">Desa Budaya</a></li>
                                <li class="breadcrumb-item"><a href="#">Detail budaya</a></li>
                            </ol>
                        </nav>
                    </div>
                </div>  
                </div>    
    
    <div class="container-fluid">
    <div class="row">
        <!-- Bagian Video -->
        <div class="col-lg-8">
            <div class="video-container">
                <?php if(isset($embed_youtube_link) && !empty($embed_youtube_link)): ?>
                    <iframe src="<?php echo e($embed_youtube_link); ?>"
                            title="YouTube video player"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowfullscreen
                            style="width: 100%; height: 370px; object-fit: cover;">
                    </iframe>
                <?php else: ?>
                    <p>Video tidak tersedia.</p>
                <?php endif; ?>
            </div>

            <!-- Carousel Slider -->
            <div class="row mt-4">
                <div class="col-lg-12">
                    <div id="photoGallery" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-inner">
                            <?php
                                $fotoSlider = $budaya->foto_slider ?? [];
                            ?>
                            <?php if(!empty($fotoSlider)): ?>
                                <?php $__currentLoopData = array_chunk($fotoSlider, 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $fotoGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="carousel-item <?php echo e($index == 0 ? 'active' : ''); ?>">
                                        <div class="row">
                                            <?php $__currentLoopData = $fotoGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-4">
                                                    <img src="<?php echo e(asset('storage/' . $foto)); ?>" alt="Foto Slider" class="d-block w-100" style="height: 300px; object-fit: cover;">
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <p class="text-center">Tidak ada foto slider yang tersedia.</p>
                            <?php endif; ?>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#photoGallery" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#photoGallery" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Kisaran Harga -->
            <?php if(!empty($budaya->harga_min) || !empty($budaya->harga_max)): ?>
                <div class="price-range mt-5">
                    <h2>Kisaran Harga</h2>
                    <p>
                        <?php if(!empty($budaya->harga_min) && !empty($budaya->harga_max)): ?>
                            Rp <?php echo e(number_format($budaya->harga_min, 0, ',', '.')); ?> - Rp <?php echo e(number_format($budaya->harga_max, 0, ',', '.')); ?>

                        <?php elseif(!empty($budaya->harga_min)): ?>
                            Mulai dari Rp <?php echo e(number_format($budaya->harga_min, 0, ',', '.')); ?>

                        <?php elseif(!empty($budaya->harga_max)): ?>
                            Hingga Rp <?php echo e(number_format($budaya->harga_max, 0, ',', '.')); ?>

                        <?php endif; ?>
                    </p>
                </div>
            <?php endif; ?>

            <!-- Deskripsi -->
            <?php if(!empty($budaya->deskripsi)): ?>
                <div class="description mt-5">
                    <h2>Description</h2>
                    <p><?php echo e($budaya->deskripsi); ?></p>
                </div>
            <?php else: ?>
                <div class="description mt-5">
                    <p>Deskripsi tidak tersedia.</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Kalender Jadwal -->
        <div class="col-lg-4 col-md-12">
            <div id="calendar-container" class="card p-4 shadow-sm">
                <div class="calendar-navigation d-flex justify-content-between align-items-center mb-3">
                    <button id="prev-month" class="btn btn-outline-secondary btn-sm">&lsaquo;&lsaquo;</button>
                    <h4 id="month-year" class="mb-0"></h4>
                    <button id="next-month" class="btn btn-outline-secondary btn-sm">&rsaquo;&rsaquo;</button>
                </div>

                <div id="calendar" class="row g-2"></div>

                <!-- Detail Jadwal di dalam kotak kalender -->
                <div id="event-description" class="mt-4 p-3 bg-light border rounded shadow-sm">
                    <h5>Detail Jadwal:</h5>
                    <p id="event-detail" class="text-muted">Klik pada tanggal yang memiliki tanda (*) untuk melihat detail acara.</p>
                </div>
            </div>

            <!-- Tombol Pesan Sekarang dengan lebar penuh -->
            <button id="pesanSekarangBtn" style="background-color: green; color: white; border: none; width: 100%; padding: 10px 20px; font-size: 16px; cursor: pointer; border-radius: 5px; margin-top: 20px;">
                Pesan Sekarang
            </button>

            <!-- WhatsApp Chat Box -->
            <div id="chatBox" style="display: none; margin-top: 20px; border: 1px solid #ddd; padding: 20px; border-radius: 10px; position: relative; width: 300px;">
                <div id="chatHeader" style="display: flex; justify-content: space-between; align-items: center;">
                    <h3 style="margin: 0;">Kirim Pesanan Anda!</h3>
                    <span id="closeChat" style="cursor: pointer; font-size: 20px; font-weight: bold; color: red;">&times;</span>
                </div>
                <textarea id="chatInput" placeholder="Ketik pesan disini" style="width: 100%; padding: 10px; border-radius: 5px; margin-bottom: 10px;"></textarea>
                <button onclick="sendWhatsAppMessage()" style="background-color: purple; color: white; border: none; padding: 10px 20px; font-size: 16px; cursor: pointer; border-radius: 5px;">
                    Kirim
                </button>
            </div>

        </div>
    </div>
</div>

<style>
.video-container {
    margin-bottom: 20px;
}
.description {
    margin-top: 20px;
}
.form-group {
    margin-bottom: 15px;
}
.btn-primary {
    background-color: #9F78FF;
    border: none;
    padding: 20px 20px;
    border-radius: 5px;
    color: white;
    cursor: pointer;
}
.btn-primary:hover {
    background-color: #8764db;
}
</style>

    <!--  Details End -->


</main>

    <footer>
    <!-- Footer Start -->
    <div class="footer-area footer-padding">
        <div class="container-fluid">
            <div class="row d-flex justify-content-around">
                <!-- Logo and Social Media -->
                <div class="col-xl-3 col-lg-3 col-md-8 col-sm-8 d-flex justify-content-center">
                    <div class="single-footer-caption mb-50">
                        <!-- Logo -->
                        <div class="footer-logo mb-35" style="text-align: right;">
                            <a href="<?php echo e(url('/')); ?>">
                                <img src="<?php echo e(asset('themewagon/img/logo/logo_footer.png')); ?>" alt="Logo Kelurahan Sinduharjo" style="width: 400px; height: 120px;">
                            </a>
                        </div>
                        <!-- Social Media Icons -->
                        <div class="footer-social">
                            <a href="https://sinduharjosid.slemankab.go.id/first" class="mr-2"><i class="fas fa-globe"></i></a>
                            <a href="https://www.instagram.com/kalurahan_sinduharjo" class="mr-2"><i class="fab fa-instagram"></i></a>
                            <a href="https://www.youtube.com/"><i class="fab fa-youtube"></i></a>
                        </div>
                    </div>
                </div>

                <!-- Quick Links -->
                <div class="col-xl-2 col-lg-2 col-md-4 col-sm-4">
                    <div class="single-footer-caption mb-50">
                        <div class="footer-tittle">
                            <h4>Link</h4>
                            <ul>
                                <li><a href="<?php echo e(url('/desabudaya')); ?>">Desa Budaya</a></li>
                                <li><a href="<?php echo e(url('/desaprima')); ?>">Desa Prima</a></li>
                                <li><a href="<?php echo e(url('/desapreneur')); ?>">Desa Preneur</a></li>
                                <li><a href="<?php echo e(url('/desawisata')); ?>">Desa Wisata</a></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- Contact Info -->
                <div class="col-xl-2 col-lg-3 col-md-4 col-sm-4">
                    <div class="single-footer-caption mb-35" style= "text-align: left;">
                        <div class="footer-tittle">
                            <h4>Kontak</h4>
                            <ul>
                                <li><a href="#">(0274) 882723</a></li>
                                <li><a href="#">sinduharjo@gmail.com</a></li>
                                <li><a href="#">Jalan Kaliurang Km 10.5, Gentan, Ngaglik, Sleman, Yogyakarta</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer-Bottom Area -->
    <div class="footer-bottom-area">
        <div class="container">
            <div class="footer-border">
                <div class="row d-flex align-items-center">
                    <div class="col-xl-12">
                        <div class="footer-copy-right text-center">
                            <p>
                                Copyright &copy; <script>document.write(new Date().getFullYear());</script>
                                All rights reserved | Kalurahan Sinduharjo
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->
</footer>
<!--? Search model Begin -->
<div class="search-model-box">
    <div class="h-100 d-flex align-items-center justify-content-center">
        <div class="search-close-btn">+</div>
        <form class="search-model-form">
            <input type="text" id="search-input" placeholder="Searching key.....">
        </form>
    </div>
</div>

<!-- Search model end -->
<!-- Scroll Up -->
<div id="back-top" >
    <a title="Go to Top" href="#"> <i class="fas fa-level-up-alt"></i></a>
</div>

<!-- JS here -->
<!-- Jquery, Popper, Bootstrap -->
<script src="<?php echo e(asset('themewagon/js/vendor/modernizr-3.5.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/vendor/jquery-1.12.4.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/bootstrap.min.js')); ?>"></script>


<!-- Slick-slider , Owl-Carousel ,slick-nav -->
<script src="<?php echo e(asset('themewagon/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.slicknav.min.js')); ?>"></script>

<!-- One Page, Animated-HeadLin, Date Picker -->
<script src="<?php echo e(asset('themewagonjs/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/animated.headline.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.magnific-popup.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/gijgo.min.js')); ?>"></script>

<!-- calendar js -->
<script>
    const agenda = <?php echo json_encode($agenda, 15, 512) ?>;
</script>
<script src="<?php echo e(asset('themewagon/js/calendar.js')); ?>"></script>

<!-- whatsapp js -->
<script src="<?php echo e(asset('themewagon/js/whatsapp.js')); ?>"></script>

<!-- Nice-select, sticky,Progress -->
<script src="<?php echo e(asset('themewagon/js/jquery.nice-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.sticky.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.barfiller.js')); ?>"></script>

<!-- counter , waypoint,Hover Direction -->
<script src="<?php echo e(asset('themewagon/js/jquery.counterup.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.countdown.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/hover-direction-snake.min.js')); ?>"></script>

<!-- contact js -->
<script src="<?php echo e(asset('themewagon/js/contact.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.form.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/mail-script.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.ajaxchimp.min.js')); ?>"></script>

<!-- Jquery Plugins, main Jquery -->	
<script src="<?php echo e(asset('themewagon/js/plugins.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/main.js')); ?>"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
    // Menampilkan chat box ketika tombol Pesan Sekarang diklik
    document.getElementById("pesanSekarangBtn").addEventListener("click", function() {
        document.getElementById("chatBox").style.display = "block";
    });

    // Menutup chat box ketika tombol Close diklik
    document.getElementById("closeChat").addEventListener("click", function() {
        document.getElementById("chatBox").style.display = "none";
    });

    function sendWhatsAppMessage() {
        var phoneNumber = "<?php echo e($budaya->nomor_whatsapp); ?>"; // Nomor WhatsApp dari database
        var message = document.getElementById("chatInput").value;

        if (message.trim() === "") {
            alert("Pesan tidak boleh kosong.");
        } else {
            var url = "https://wa.me/" + phoneNumber + "?text=" + encodeURIComponent(message);
            window.open(url, "_blank");
        }
    }
</script>
<script>$('.carousel').carousel()</script>

</body>
</html><?php /**PATH C:\xampp\htdocs\project\resources\views/beranda/detail_budaya.blade.php ENDPATH**/ ?>