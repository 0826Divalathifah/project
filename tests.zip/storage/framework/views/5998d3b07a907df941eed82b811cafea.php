<!doctype html>
<html class="no-js" lang="zxx">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Desa Preneur</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="manifest" href="site.webmanifest">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('themewagon/img/favicon.ico')); ?>">

    <!-- CSS here -->
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/slicknav.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/progressbar_barfiller.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/gijgo.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/animated-headline.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/magnific-popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/fontawesome-all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/nice-select.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/style.css')); ?>">
  

</head>
<body class="full-wrapper">
    <!-- Preloader Start -->
    <div id="preloader-active">
        <div class="preloader d-flex align-items-center justify-content-center">
            <div class="preloader-inner position-relative">
                <div class="preloader-circle"></div>
                <div class="preloader-img pere-text">
                <img src="<?php echo e(asset('themewagon/img/logo/logo Kabupaten Sleman.png')); ?>" alt="">
                </div>
            </div>
        </div>
    </div>
    <!-- Preloader Start -->
<header>
    <!-- Header Start -->
    <div class="header-area">
        <div class="main-header header-sticky">
            <div class="container-fluid">
                <div class="menu-wrapper d-flex align-items-center justify-content-between">
                    <div class="header-left d-flex align-items-center">
                         <!-- Logo -->
                         <div class="logo">
                            <a href="<?php echo e(url('/')); ?>">
                                <img src="<?php echo e(asset('themewagon/img/logo/logo_header.png')); ?>" alt="Logo Kabupaten Sleman" style="width: 97 px; height: 70px;">
                                </a> </div>
                        <!-- Main-menu -->
                        <div class="main-menu d-none d-lg-block">
                            <nav>
                                <ul id="navigation">
                                    <li><a href="<?php echo e(url('/')); ?>">Beranda</a></li>
                                    <li><a href="#">Desa Mandiri Budaya</a>
                                        <ul class="submenu">
                                            <li><a href="<?php echo e(url('/desabudaya')); ?>">Desa Budaya </a></li>
                                            <li><a href="<?php echo e(url('/desaprima')); ?>">Desa Prima</a></li>
                                            <li><a href="<?php echo e(url('/desapreneur')); ?>">Desa Preneur</a></li>
                                            <li><a href="<?php echo e(url('/desawisata')); ?>">Desa Wisata</a></li>
                                        </ul>
                                    <li>   
                                    <li><a href="<?php echo e(url('/about')); ?>">Tentang Kami</a></li>
                                    <li><a href="<?php echo e(url('/contact')); ?>">Kontak</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <div class="header-right1 d-flex align-items-center">
                        <!-- Social -->
                        <div class="header-social d-none d-md-block">
                            <a href="https://sinduharjosid.slemankab.go.id/first"><i class="fas fa-globe"></i></a>
                            <a href="https://www.instagram.com/kalurahan_sinduharjo?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="><i class="fab fa-instagram"></i></a>
                            <a href="https://www.youtube.com/"><i class="fab fa-youtube"></i></a>
                        </div>
                        <!-- Search Box 
                        <div class="search d-none d-md-block">
                            <ul class="d-flex align-items-center">
                                <li class="mr-15">
                                    <div class="nav-search search-switch">
                                        <i class="ti-search"></i>
                                    </div>
                                </li>
                            </ul>
                        </div>-->
                    </div>
                    <!-- Mobile Menu -->
                    <div class="col-12">
                        <div class="mobile_menu d-block d-lg-none"></div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Header End -->
    </header>
    <main>
        <!-- listing Area Start -->
        <div class="category-area">
            <div class="container">
                <div class="row">
            
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">

                    <div class="banner-container">
                        <!-- Mobile Device Show Menu-->
                <div class="header-right2 d-flex align-items-center">
                    <!-- Social -->
                    <div class="header-social  d-block d-md-none">
                    <a href="https://sinduharjosid.slemankab.go.id/first"><i class="fas fa-globe"></i></a>
                    <a href="https://www.instagram.com/kalurahan_sinduharjo?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="><i class="fab fa-instagram"></i></a>
                    <a href="https://www.youtube.com/"><i class="fab fa-youtube"></i></a>
                    <!-- Ikon Login dan Sign Up -->
                    </div>
                </div>
                        <div class="banner-overlay"></div>
                        <div class="banner-text">Desa Preneur</div>

                        <?php if(isset($gambar_banner) && file_exists(public_path('storage/' . $gambar_banner))): ?>
                                <img src="<?php echo e(asset('storage/' . $gambar_banner)); ?>" alt="Banner" class="banner-image">
                            <?php else: ?>
                                <img src="<?php echo e(asset('themewagon/img/desabudaya/banner.jpg')); ?>" alt="Banner" class="banner-image">
                            <?php endif; ?>

                    <!-- breadcrumb Start-->
                    <div class="breadcrumb">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center">
                                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Beranda</a></li>
                                <li class="breadcrumb-item"><a href="#">Desa Preneur</a></li>
                            </ol>
                        </nav>
                    </div>
                </div>


</main>
    <div class="row">
       <!--? Left content -->
       <div class="col-xl-3 col-lg-3 col-md-4">
            <div class="category-listing mb-50">
                <div class="single-listing">
                    <div class="select-job-items2">
                        <select name="select2" id="categorySelect" onchange="navigateToSection()">
                            <option value="">--Pilih Kategori--</option>
                            <option value="makanan">Makanan dan Minuman</option>
                            <option value="kerajinan">Kerajinan dan Aksesoris</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-9 col-lg-9 col-md-8">
        <!-- Makanan Section -->
        <div id="makanan" class="slider" >
            <?php if($makanan->isEmpty()): ?>
                <p>Tidak ada produk makanan tersedia.</p>
            <?php else: ?>
                <?php $__currentLoopData = $makanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card">
                        <img src="<?php echo e(asset('storage/' . $produk->foto_card)); ?>" alt="<?php echo e($produk->nama_produk); ?>">
                        <div class="card-body">
                            <h5 class="card-title"><a href="<?php echo e(url('/detail_preneur', $produk->id)); ?>"><?php echo e($produk->nama_produk); ?></a></h5>
                            <span style="color: #FF5733;"><?php echo e($produk->harga_produk); ?></span>
                            <p class="card-text"><?php echo e($produk->deskripsi); ?></p>
                            <a href="<?php echo e(url('/detail_preneur', ['id' => $produk->id])); ?>" class="btn btn-primary">Selengkapnya</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>

        <!-- Kerajinan Section -->
        <div id="kerajinan" class="slider" >
            <?php if($kerajinan->isEmpty()): ?>
                <p>Tidak ada produk kerajinan tersedia.</p>
            <?php else: ?>
                <?php $__currentLoopData = $kerajinan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card">
                        <img src="<?php echo e(asset('storage/' . $produk->foto_card)); ?>" alt="<?php echo e($produk->nama_produk); ?>">
                        <div class="card-body">
                            <h5 class="card-title"><a href="<?php echo e(url('/detail_preneur', $produk->id)); ?>"><?php echo e($produk->nama_produk); ?></a></h5>
                            <span style="color: #FF5733;"> <?php echo e($produk->harga_produk); ?></span>
                            <p class="card-text"><?php echo e($produk->deskripsi); ?></p>
                            <a href="<?php echo e(url('/detail_preneur', $produk->id)); ?>" class="btn">Selengkapnya</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
   
<script>
    function navigateToSection() {
        document.getElementById("makanan").style.display = "none";
        document.getElementById("kerajinan").style.display = "none";

        var selectedCategory = document.getElementById("categorySelect").value;

        if (selectedCategory) {
            document.getElementById(selectedCategory).style.display = "block";
        }
    }
</script>
<!-- listing-area Area End -->


<footer>
    <!-- Footer Start -->
    <div class="footer-area footer-padding">
        <div class="container-fluid">
            <div class="row d-flex justify-content-around">
                <!-- Logo and Social Media -->
                <div class="col-xl-3 col-lg-3 col-md-8 col-sm-8 d-flex justify-content-center">
                    <div class="single-footer-caption mb-50">
                        <!-- Logo -->
                        <div class="footer-logo mb-35" style="text-align: right;">
                            <a href="<?php echo e(url('/')); ?>">
                                <img src="<?php echo e(asset('themewagon/img/logo/logo_footer.png')); ?>" alt="Logo Kelurahan Sinduharjo" style="width: 400px; height: 120px;">
                            </a>
                        </div>
                        <!-- Social Media Icons -->
                        <div class="footer-social">
                            <a href="https://sinduharjosid.slemankab.go.id/first" class="mr-2"><i class="fas fa-globe"></i></a>
                            <a href="https://www.instagram.com/kalurahan_sinduharjo" class="mr-2"><i class="fab fa-instagram"></i></a>
                            <a href="https://www.youtube.com/"><i class="fab fa-youtube"></i></a>
                        </div>
                    </div>
                </div>

                <!-- Quick Links -->
                <div class="col-xl-2 col-lg-2 col-md-4 col-sm-4">
                    <div class="single-footer-caption mb-50">
                        <div class="footer-tittle">
                            <h4>Link</h4>
                            <ul>
                                <li><a href="<?php echo e(url('/desabudaya')); ?>">Desa Budaya</a></li>
                                <li><a href="<?php echo e(url('/desaprima')); ?>">Desa Prima</a></li>
                                <li><a href="<?php echo e(url('/desapreneur')); ?>">Desa Preneur</a></li>
                                <li><a href="<?php echo e(url('/desawisata')); ?>">Desa Wisata</a></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- Contact Info -->
                <div class="col-xl-2 col-lg-3 col-md-4 col-sm-4">
                    <div class="single-footer-caption mb-35" style= "text-align: left;">
                        <div class="footer-tittle">
                            <h4>Kontak</h4>
                            <ul>
                                <li><a href="#">(0274) 882723</a></li>
                                <li><a href="#">kalurahansinduharjo@gmail.com</a></li>
                                <li><a href="#">Jalan Kaliurang Km 10.5, Gentan, Ngaglik, Sleman, Yogyakarta</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer-Bottom Area -->
    <div class="footer-bottom-area">
        <div class="container">
            <div class="footer-border">
                <div class="row d-flex align-items-center">
                    <div class="col-xl-12">
                        <div class="footer-copy-right text-center">
                            <p>
                                Copyright &copy; <script>document.write(new Date().getFullYear());</script>
                                All rights reserved | Kalurahan Sinduharjo
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->
</footer>

<!--? Search model Begin
<div class="search-model-box">
    <div class="h-100 d-flex align-items-center justify-content-center">
        <div class="search-close-btn">+</div>
        <form class="search-model-form">
            <input type="text" id="search-input" placeholder="Searching key.....">
        </form>
    </div>
</div> -->

<!-- Scroll Up -->
<div id="back-top" >
    <a title="Go to Top" href="#"> <i class="fas fa-level-up-alt"></i></a>
</div>

<!-- JS here -->
<!-- Jquery, Popper, Bootstrap -->
<script src="<?php echo e(asset('themewagon/js/vendor/modernizr-3.5.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/vendor/jquery-1.12.4.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/bootstrap.min.js')); ?>"></script>


<!-- Slick-slider , Owl-Carousel ,slick-nav -->
<script src="<?php echo e(asset('themewagon/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.slicknav.min.js')); ?>"></script>

<!-- One Page, Animated-HeadLin, Date Picker -->
<script src="<?php echo e(asset('themewagonjs/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/animated.headline.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.magnific-popup.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/gijgo.min.js')); ?>"></script>


<!-- Nice-select, sticky,Progress -->
<script src="<?php echo e(asset('themewagon/js/jquery.nice-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.sticky.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.barfiller.js')); ?>"></script>

<!-- counter , waypoint,Hover Direction -->
<script src="<?php echo e(asset('themewagon/js/jquery.counterup.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.countdown.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/hover-direction-snake.min.js')); ?>"></script>

<!-- contact js -->
<script src="<?php echo e(asset('themewagon/js/contact.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.form.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/mail-script.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.ajaxchimp.min.js')); ?>"></script>

<!-- Jquery Plugins, main Jquery -->	
<script src="<?php echo e(asset('themewagon/js/plugins.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/main.js')); ?>"></script>

</body>
</html><?php /**PATH C:\xampp\htdocs\project\resources\views/beranda/desapreneur.blade.php ENDPATH**/ ?>