<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Detail</title>

    <!-- CSS here -->
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/slicknav.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/progressbar_barfiller.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/gijgo.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/animated-headline.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/magnific-popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/fontawesome-all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/nice-select.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('themewagon/css/detail.min.css')); ?>">


</head>
<body>

<!-- Header Start -->
<header>
    <div class="header-area">
        <div class="main-header header-sticky">
            <div class="container-fluid">
                <div class="menu-wrapper d-flex align-items-center justify-content-between">
                    <div class="header-left d-flex align-items-center">
                        <!-- Logo -->
                        <div class="logo">
                            <a href="<?php echo e(url('/')); ?>">
                                <img src="<?php echo e(asset('themewagon/img/logo/logo_header.png')); ?>" alt="Logo Kabupaten Sleman" style="width: 200px; height: 70px;">
                            </a>
                        </div>
                        <!-- Main-menu -->
                        <div class="main-menu d-none d-lg-block">
                            <nav>
                                <ul id="navigation">
                                    <li><a href="<?php echo e(url('/')); ?>">Beranda</a></li>
                                    <li><a href="#">Desa Mandiri Budaya</a>
                                        <ul class="submenu">
                                            <li><a href="<?php echo e(url('/desabudaya')); ?>">Desa Budaya</a></li>
                                            <li><a href="<?php echo e(url('/desaprima')); ?>">Desa Prima</a></li>
                                            <li><a href="<?php echo e(url('/desapreneur')); ?>">Desa Preneur</a></li>
                                            <li><a href="<?php echo e(url('/desawisata')); ?>">Desa Wisata</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="<?php echo e(url('/about')); ?>">Tentang Kami</a></li>
                                    <li><a href="<?php echo e(url('/contact')); ?>">Kontak</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <div class="header-right1 d-flex align-items-center">
                        <!-- Social -->
                        <div class="header-social d-none d-md-block">
                            <a href="https://sinduharjosid.slemankab.go.id/first"><i class="fas fa-globe"></i></a>
                            <a href="https://www.instagram.com/kalurahan_sinduharjo?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="><i class="fab fa-instagram"></i></a>
                            <a href="https://www.youtube.com/"><i class="fab fa-youtube"></i></a>
                        </div>
                    </div>
                    <!-- Mobile Menu -->
                    <div class="col-12">
                        <div class="mobile_menu d-block d-lg-none"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- Header End -->
<div class="container">
    <div class="product-detail">
        <!-- Gambar Produk -->
        <div class="product-image">
            <div id="productCarousel" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="<?php echo e(asset('themewagon/img/desaprima/produk1.jpeg')); ?>" class="d-block w-100" alt="Product Image 1">
                    </div>
                    <div class="carousel-item">
                        <img src="<?php echo e(asset('themewagon/img/desaprima/produk2.jpeg')); ?>" class="d-block w-100" alt="Product Image 2">
                    </div>
                    <div class="carousel-item">
                        <img src="<?php echo e(asset('themewagon/img/desaprima/produk3.jpeg')); ?>" class="d-block w-100" alt="Product Image 3">
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#productCarousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#productCarousel" data-bs-slide="next">
                  
                </button>
            </div>
        </div>

        <!-- Detail Produk -->
        <div class="product-details">
            <h2>Briza Brownies</h2>
            <p class="price">Rp 30.000</p>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quis possimus perspiciatis dolorem earum minus voluptatibus atque.</p>

            <!-- Pilih Ukuran -->
            <label for="Toping">Toping:</label>
            <select id="size">
                <option value="none">Pilih Toping</option>
                <option value="1">Coklat</option>
                <option value="2">Keju</option>
            </select>

            <!-- Tombol Beli -->
            <div class="actions">
                <button class="btn add-to-cart" id="beliBtn" style="background-color: purple; color: white; border: none; padding: 15px 30px; font-size: 18px; cursor: pointer; border-radius: 5px;">
                    Beli
                </button>
            </div>

            <!-- WhatsApp Chat Box (Detail Pesanan) -->
                <div id="chatBox" style="display: none; margin-top: 30px; border: 1px solid #ddd; padding: 30px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); position: relative; width: 100%; max-width: 500px; background-color: #f9f9f9;">
                    <div id="chatHeader" style="display: flex; justify-content: space-between; align-items: center;">
                        <h3 style="margin: 0; font-size: 22px; color: #333;">Detail Pesanan</h3>
                        <!-- Tombol Close -->
                        <span id="closeChat" style="cursor: pointer; font-size: 24px; font-weight: bold; color: #dc3545;">&times;</span>
                    </div>
                    
                    <!-- Detail Produk dalam Kartu -->
                    <div style="margin-top: 20px; background-color: white; border-radius: 8px; padding: 20px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);">
                        <p style="margin: 0; font-size: 18px;"><strong>Produk:</strong> <span id="productName">Nama Produk</span></p>
                        <p style="margin: 10px 0 0 0; font-size: 18px;"><strong>Harga:</strong> <span id="productPrice">Rp 150.000</span></p>
                        <p style="margin: 10px 0 0 0; font-size: 18px;"><strong>Jumlah:</strong> <span id="productQuantity">1</span></p>
                    </div>

                    <!-- Tombol Simpan dan Kirim ke WhatsApp -->
                    <button onclick="confirmOrderDetails()" style="background-color: #007bff; color: white; border: none; padding: 15px 30px; font-size: 18px; cursor: pointer; border-radius: 8px; margin-top: 20px; width: 100%;">
                        Simpan dan Lanjutkan ke WhatsApp
                    </button>
                </div>
            </div>
        </div>
            
    </div>
</div>

<footer>
    <!-- Footer Start -->
    <div class="footer-area footer-padding">
        <div class="container-fluid">
            <div class="row d-flex justify-content-around">
                <!-- Logo and Social Media -->
                <div class="col-xl-3 col-lg-3 col-md-8 col-sm-8 d-flex justify-content-center">
                    <div class="single-footer-caption mb-50">
                        <!-- Logo -->
                        <div class="footer-logo mb-35" style="text-align: right;">
                            <a href="<?php echo e(url('/')); ?>">
                                <img src="<?php echo e(asset('themewagon/img/logo/logo_footer.png')); ?>" alt="Logo Kelurahan Sinduharjo" style="width: 400px; height: 120px;">
                            </a>
                        </div>
                        <!-- Social Media Icons -->
                        <div class="footer-social">
                            <a href="https://sinduharjosid.slemankab.go.id/first" class="mr-2"><i class="fas fa-globe"></i></a>
                            <a href="https://www.instagram.com/kalurahan_sinduharjo" class="mr-2"><i class="fab fa-instagram"></i></a>
                            <a href="https://www.youtube.com/"><i class="fab fa-youtube"></i></a>
                        </div>
                    </div>
                </div>

                <!-- Quick Links -->
                <div class="col-xl-2 col-lg-2 col-md-4 col-sm-4">
                    <div class="single-footer-caption mb-50">
                        <div class="footer-tittle">
                            <h4>Link</h4>
                            <ul>
                                <li><a href="<?php echo e(url('/desabudaya')); ?>">Desa Budaya</a></li>
                                <li><a href="<?php echo e(url('/desaprima')); ?>">Desa Prima</a></li>
                                <li><a href="<?php echo e(url('/desapreneur')); ?>">Desa Preneur</a></li>
                                <li><a href="<?php echo e(url('/desawisata')); ?>">Desa Wisata</a></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- Contact Info -->
                <div class="col-xl-2 col-lg-3 col-md-4 col-sm-4">
                    <div class="single-footer-caption mb-35" style= "text-align: left;">
                        <div class="footer-tittle">
                            <h4>Kontak</h4>
                            <ul>
                                <li><a href="#">(0274) 882723</a></li>
                                <li><a href="#">sinduharjo@gmail.com</a></li>
                                <li><a href="#">Jalan Kaliurang Km 10.5, Gentan, Ngaglik, Sleman, Yogyakarta</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer-Bottom Area -->
    <div class="footer-bottom-area">
        <div class="container">
            <div class="footer-border">
                <div class="row d-flex align-items-center">
                    <div class="col-xl-12">
                        <div class="footer-copy-right text-center">
                            <p>
                                Copyright &copy; <script>document.write(new Date().getFullYear());</script>
                                All rights reserved | Kalurahan Sinduharjo
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->
</footer>

<!--? Search model Begin -->
<div class="search-model-box">
    <div class="h-100 d-flex align-items-center justify-content-center">
        <div class="search-close-btn">+</div>
        <form class="search-model-form">
            <input type="text" id="search-input" placeholder="Searching key.....">
        </form>
    </div>
</div>
<!-- Search model end -->
<!-- Scroll Up -->
<div id="back-top" >
    <a title="Go to Top" href="#"> <i class="fas fa-level-up-alt"></i></a>
</div>
    </footer>

<!-- JS here -->
<!-- Jquery, Popper, Bootstrap -->
<script src="<?php echo e(asset('themewagon/js/vendor/modernizr-3.5.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/vendor/jquery-1.12.4.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/bootstrap.min.js')); ?>"></script>


<!-- Slick-slider , Owl-Carousel ,slick-nav -->
<script src="<?php echo e(asset('themewagon/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.slicknav.min.js')); ?>"></script>

<!-- One Page, Animated-HeadLin, Date Picker -->
<script src="<?php echo e(asset('themewagonjs/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/animated.headline.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.magnific-popup.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/gijgo.min.js')); ?>"></script>


<!-- Nice-select, sticky,Progress -->
<script src="<?php echo e(asset('themewagon/js/jquery.nice-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.sticky.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.barfiller.js')); ?>"></script>

<!-- counter , waypoint,Hover Direction -->
<script src="<?php echo e(asset('themewagon/js/jquery.counterup.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.countdown.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/hover-direction-snake.min.js')); ?>"></script>

<!-- contact js -->
<script src="<?php echo e(asset('themewagon/js/contact.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.form.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/mail-script.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/jquery.ajaxchimp.min.js')); ?>"></script>

<!-- Jquery Plugins, main Jquery -->	
<script src="<?php echo e(asset('themewagon/js/plugins.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/main.js')); ?>"></script>


<script src="<?php echo e(asset('themewagon/js/whatsapp.js')); ?>"></script>
<script src="<?php echo e(asset('themewagon/js/detail.js')); ?>"></script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\project\resources\views/beranda/detail_produk.blade.php ENDPATH**/ ?>