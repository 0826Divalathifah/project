<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Hasil Pencarian untuk: "<?php echo e($keyword); ?>"</h2>
        
        <!-- Jika ada hasil pencarian, tampilkan di sini -->
        
        
        <!-- Jika belum ada logika pencarian, tampilkan placeholder -->
        <p>Fungsi pencarian belum terimplementasi.</p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/search_results.blade.php ENDPATH**/ ?>